import React from 'react';

const LandingPage: React.FC = () => {
  return (
    <div className="min-h-screen bg-gradient-to-b from-blue-50 to-white">
      <div className="container px-4 py-16 mx-auto">
        <div className="text-center">
          <h1 className="mb-6 text-5xl font-bold text-gray-900">
            Welcome to Our Platform
          </h1>
          <p className="max-w-2xl mx-auto mb-8 text-xl text-gray-600">
            Build amazing websites with our intuitive drag-and-drop builder.
            No coding required!
          </p>
        </div>
      </div>
    </div>
  );
};

export default LandingPage;