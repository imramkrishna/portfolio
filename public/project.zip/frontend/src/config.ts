export const config = {
  apiUrl: import.meta.env.VITE_API_URL || 'http://localhost:3000',
  appName: import.meta.env.VITE_APP_NAME || 'Fullstack App',
  isDevelopment: import.meta.env.MODE === 'development',
};