import React from 'react';

const Header: React.FC = () => {
  return (
    <header className="bg-white border-b shadow-sm">
      <div className="container px-4 py-4 mx-auto">
        <div className="flex items-center justify-between">
          <div className="text-2xl font-bold text-gray-900">
            Platform
          </div>
          <nav className="flex space-x-6">
            <a href="#" className="text-gray-600 transition-colors hover:text-gray-900">
              Home
            </a>
            <a href="#" className="text-gray-600 transition-colors hover:text-gray-900">
              About
            </a>
          </nav>
        </div>
      </div>
    </header>
  );
};

export default Header;