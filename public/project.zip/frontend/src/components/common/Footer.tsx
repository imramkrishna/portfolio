import React from 'react';

const Footer: React.FC = () => {
  return (
    <footer className="py-8 text-white bg-gray-800">
      <div className="container px-4 mx-auto">
        <div className="text-center">
          <p>&copy; 2024 Platform. All rights reserved.</p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;