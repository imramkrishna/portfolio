import React from 'react';

interface PostProps {
  content: string;
  username: string;
  createdAt: string;
}

const Post: React.FC<PostProps> = ({ content, username, createdAt }) => {
  return (
    <div className="bg-white p-4 rounded shadow mb-4">
      <div className="flex justify-between items-center mb-2">
        <h3 className="font-bold">{username}</h3>
        <span className="text-sm text-gray-500">{new Date(createdAt).toLocaleDateString()}</span>
      </div>
      <p>{content}</p>
    </div>
  );
};

export default Post;