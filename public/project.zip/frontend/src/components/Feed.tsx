import React from 'react';
import Post from './Post';

const Feed: React.FC = () => {
  const [posts, setPosts] = React.useState([
    { content: 'First post!', username: 'user1', createdAt: new Date().toISOString() },
    { content: 'Second post!', username: 'user2', createdAt: new Date().toISOString() },
  ]);

  return (
    <div className="space-y-4">
      {posts.map((post, index) => (
        <Post 
          key={index} 
          content={post.content} 
          username={post.username} 
          createdAt={post.createdAt} 
        />
      ))}
    </div>
  );
};

export default Feed;