import React from 'react';

interface UserProfileProps {
  username: string;
  headline: string;
  bio: string;
  profilePicture: string;
}

const UserProfile: React.FC<UserProfileProps> = ({ username, headline, bio, profilePicture }) => {
  return (
    <div className="bg-white p-4 rounded shadow">
      <div className="flex items-center mb-4">
        <img 
          src={profilePicture} 
          alt="Profile" 
          className="w-20 h-20 rounded-full mr-4"
        />
        <div>
          <h2 className="text-xl font-bold">{username}</h2>
          <p className="text-gray-600">{headline}</p>
        </div>
      </div>
      <p className="text-gray-700">{bio}</p>
    </div>
  );
};

export default UserProfile;