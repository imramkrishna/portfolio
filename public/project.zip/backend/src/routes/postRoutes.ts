import { Router } from 'express';
import { createPost, getPosts } from '../controllers/postController';
import { authenticate } from '../middleware/auth';

const router = Router();

router.post('/', authenticate, createPost);
router.get('/', authenticate, getPosts);

export default router;