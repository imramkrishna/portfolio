import { Schema, model } from 'mongoose';

const userSchema = new Schema({
  username: { type: String, unique: true, required: true },
  email: { type: String, unique: true, required: true },
  password: { type: String, required: true },
  profilePicture: { type: String, default: '' },
  fullName: { type: String, required: true },
  headline: { type: String, default: '' },
  bio: { type: String, default: '' },
  connections: [{ type: Schema.Types.ObjectId, ref: 'User' }],
  posts: [{ type: Schema.Types.ObjectId, ref: 'Post' }],
}, { timestamps: true });

export default model('User', userSchema);