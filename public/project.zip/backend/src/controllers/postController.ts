import { Request, Response } from 'express';
import Post from '../models/post';

export const createPost = async (req: Request, res: Response) => {
  try {
    const { content } = req.body;
    const post = new Post({ user: req.user.id, content });
    await post.save();
    res.status(201).json({ message: 'Post created', post });
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
};

export const getPosts = async (req: Request, res: Response) => {
  try {
    const posts = await Post.find().populate('user');
    res.json(posts);
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
};